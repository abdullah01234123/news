# ReelShelf PHP catalogue starter

An original, responsive PHP movie/series discovery catalogue inspired by broad patterns common to entertainment catalogue sites. It is **not** a line-for-line clone of HDHub4u and does not include unauthorized movie files or download mirrors.

## Features

- Responsive dark UI with a feature banner, navigation, search, category filters, title cards, and title detail pages.
- PHP-rendered search and filters (no database required).
- Original locally generated SVG demo poster artwork.
- Detail pages link to a search for official viewing options, rather than directly to unlicensed file mirrors.
- Basic SEO title/meta description and HTML escaping for displayed values.

## Run locally

Requires PHP 8.0 or newer.

1. Extract the project folder.
2. Open a terminal inside `reelshelf-php/`.
3. Run:

   ```bash
   php -S localhost:8000
   ```

4. Visit `http://localhost:8000`.

## Put it online

Upload the files to a PHP-enabled host (PHP 8+). Keep `index.php` in the document root and preserve the `assets/` directory structure. HTTPS is recommended.

## Edit or add titles

Edit the `$catalog` array near the top of `index.php`. Each record has a `slug`, `title`, `year`, `kind`, `genres`, `language`, `quality`, `runtime`, `rating`, `poster`, `tagline`, and `synopsis`. Place owned or properly licensed poster artwork in `assets/posters/` and point the `poster` field at it. Keep slugs unique and URL-safe.

Categories currently supported by the filter are `All`, `Movie`, `Series`, `Animation`, `Documentary`, and `Short Film`. Genre links can also filter the list if the category is present in a title's `genres` array.

## Important

The listed films/series and poster art are fictional demo content. The displayed ratings are sample editorial scores, not real-world ratings. Replace the contact placeholder (`hello@example.com`) before publishing. Only promote media you own or have permission to promote, and link to authorized viewing options.
